import React from "react";

    const UserData = React.createContext();

  export default UserData;

