import React from "react";

export default function Footer(){

    return (<>
    <div className='bg-dark p-3 m-0 d-flex '>
         <p className='text-white text-center p-0 pt-2 w-50'>Copyright @ 2022 React First App - Course Website </p>
         <p className='text-white text-center p-0 pt-2 w-50'>  All Rights Reserved - React First App 2022 </p>
    </div>
    </>)
}