import React from 'react';

function PostStatus({postText,postSubmit,postOnChange}) {

    return (
        <div className="form-wrapper p-4 ">
            <form>
            <div className=" text-center mt-4 ">
                <textarea type="text" rows="4" cols="100" className="rounded text-center pt-3"  value = { postText } onChange = { event=>postOnChange(event) } placeholder="Text Some Messages..."> </textarea>
            </div>
            {
                postText.trim().length > 0 ? (
                    <>
                    <button type='button' className="btn form-btn " onClick={ postSubmit }> Send Messages </button>
                    </>
                ) : null
            }
            </form>
        </div>
    )
}
export default PostStatus;