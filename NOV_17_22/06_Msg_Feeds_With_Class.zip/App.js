import React,{ Component } from 'react';
import './App.css';
import PostStatus from './PostStatus';
import ShowPost from './ShowPost';
class App extends Component{

  constructor(props){
    super(props);
    this.state ={
      postText: "",
      allPosts: [],
    }
  }

  postSubmit = (e) => {
      let newPostText = [this.state.postText,...this.state.allPosts];
      this.setState({
        postText : "",
        allPosts : newPostText,
      })
  }

  removePost =(id) =>{
    let postsCopy = [...this.state.allPosts];
    postsCopy.splice(id,1);
    this.setState({
      allPosts : postsCopy,
    })
  }

 postOnChange = (event) => {
      this.setState({
        postText : event.target.value
      })
 }

  render() {
    return (
      <div className="App p-3">
        <div className="wrapper">
          <h3 className="app-title text-center ">Status Update App</h3>
          <PostStatus postText = {this.state.postText} postSubmit = {this.postSubmit} postOnChange = {this.postOnChange}/>
          <ShowPost allPosts = {this.state.allPosts} removePost = {this.removePost}/>
        </div>
      </div>
    );
  }

}

export default App;

