import React from 'react';
function ShowPost({ allPosts, removePost }) {
    // const d = new Date();
    // let mins = d.getMinutes();
    // let hrs = d.getHours();

    const msgs = allPosts;
    return (<div class="w-75 m-auto p-5">{
        msgs.map((val, index) => {
            return (
                <React.Fragment key={val}>
                    <div className="mt-4 p-3 rounded bg-info Single-Msg">
                        <i className="fa fa-times fa-fw cross-icon" onClick={()=>removePost(index)}></i>
                        <h1 className="text-center">{val}</h1>
                        <span className ="key-value"> message {index+1}</span>
                        <span className ="timing"> Posted Today</span>
                    </div>
                </React.Fragment>
            )
        })
    }</div>)
}
export default ShowPost;